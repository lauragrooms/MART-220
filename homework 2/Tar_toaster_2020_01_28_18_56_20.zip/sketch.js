var x = 113;
var diameter = 75;
var speed = 3;
let theCircle;
let theSquare;
var count = 0;
var shapeType;
let mic = 1;

function setup() 
{
  createCanvas(400, 400);
  theCircle = new myCircle(100,200,45,57, 170, 212);
  theSquare = new mySquare(224,250,90,235, 160, 47);
}

function draw() 
{
  background(235, 64, 52);
  fill(80,300,100);
  rect(5,5,390,25);
  rect(5,370,390,25);
  rect(5,37,25,330);
  rect(370,35,25,330);
  fill(20,200,70);
  textSize(32);
  text(count,30,60);
  count++;
  if (count>1000)
  {
    
    if (mic==1)
    {
     mic=0; 
    }
    else{
     mic=1; 
    }
    
    count=0;
  }
  if (mic==1)
  {
   theSquare.display("circle"); 
  }
    
  else {
    theSquare.display("square");
  }
  
}

class myCircle 
{

  constructor(x,y,diameter,red,green,blue)
  {
    this.x = x;
    this.y = y;
    this.diameter = diameter;
    this.red = red;
    this.green = green;
    this.blue = blue;
    this.speed = 10;
  }
  
  display()
  {
     fill(this.red,this.green,this.blue);
     circle(this.x,this.y, this.diameter); 
  }

}

class mySquare 
{

  constructor(x,y,side,red,green,blue)
  {
    this.x = random(200,200);
    this.y = random(200,200);
    this.side = side;
    this.red = red;
    this.green = green;
    this.blue = blue;
    
  }
  
  display(shapeType)
  {
     fill(this.red,this.green,this.blue);
    if (shapeType == "square")
    {
      circle(random(100,300),random(100,300),this.side);
    }
    else {
      square(random(100,300),random(100,300),this.side);
    }
         
  }
  
}